import copy
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import scanner

class ScannerTests(unittest.TestCase):
    def test_discovery_dedup_and_first_seen(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            cfg=root/'config.json'; db=root/'repos.json'; output=root/'data.json'
            cfg.write_text(json.dumps({'topics':[{'name':'macos','enabled':True},{'name':'menubar','enabled':True}], 'scan':{'pages_per_topic':1}}))
            item={'id':123,'name':'sample','full_name':'dev/sample','html_url':'https://github.com/dev/sample','description':'A Mac menu bar app','stargazers_count':5,'topics':['macos'],'license':{'spdx_id':'MIT'}}
            def fake(topic,page,token):return {'items':[copy.deepcopy(item)],'total_count':1}
            with patch.object(scanner,'CONFIG',cfg),patch.object(scanner,'DATABASE',db),patch.object(scanner,'OUTPUT',output):
                first=scanner.scan(fetch=fake,now='2026-10-31T12:00:00+00:00')
                second=scanner.scan(fetch=fake,now='2026-11-01T12:00:00+00:00')
            self.assertEqual(first['new'],1)
            self.assertEqual(second['new'],0)
            result=json.loads(db.read_text())['repositories']
            self.assertEqual(len(result),1)
            self.assertEqual(result['123']['first_seen'],'2026-10-31T12:00:00+00:00')
            self.assertEqual(set(result['123']['matching_topics']),{'macos','menubar'})
    def test_failed_topic_is_recorded(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); cfg=root/'config.json'; db=root/'repos.json'; out=root/'data.json'
            cfg.write_text(json.dumps({'topics':[{'name':'macos','enabled':True}]}))
            with patch.object(scanner,'CONFIG',cfg),patch.object(scanner,'DATABASE',db),patch.object(scanner,'OUTPUT',out):
                result=scanner.scan(fetch=lambda *args: (_ for _ in ()).throw(RuntimeError('network down')))
            self.assertEqual(len(result['errors']),1)
            self.assertIn('network down',result['topics'][0]['status'])
if __name__=='__main__':unittest.main()
